# FogSift Prompt Pack

Build your own fact-checking content engine with Claude. No coding required.

FogSift turns a foggy idea into a verified video script. It thinks the idea through, tests every claim, writes a script from only what survived, then flags any sentence that isn't backed up.

This pack is the prompts I used to build it. Paste them into Claude and you get your own version, built your way.

## What's inside

| File | What it does |
|---|---|
| `01-build-browser.md` | One prompt. Builds FogSift as a web page inside Claude. Easiest start. |
| `02-build-local.md` | One prompt. Builds FogSift as a private tool that runs on your own computer with llama.cpp. |
| `03-stage-prompts.md` | The five prompts that power each stage. Use them by hand in any chat, no app needed. |
| `04-upgrades.md` | Prompts to add features: thumbnails, Shorts, live research, quiz mode, your own voice. |
| `05-make-it-yours.md` | Prompts to point FogSift at your niche: cooking, finance, fitness, tech, local news. |
| `examples/` | What I built with these prompts: the web version, the local version, and a finished script. |

## Fastest path (5 minutes)

1. Open [claude.ai](https://claude.ai).
2. Copy everything inside the box in `01-build-browser.md` and paste it.
3. Type an idea and press Sift it.

## How the prompts work

Each build prompt is complete on its own. It tells Claude exactly what to build, how each stage behaves, and what rules keep it honest. You can edit anything in brackets `[like this]` before pasting.

If Claude's result isn't quite right, just tell it what to change. That's the whole point: you're not buying my code, you're buying the recipe so you can make it fit you.

## The one rule that makes FogSift work

The evidence decides the verdict, not the AI. A claim is SUPPORTED only if every piece of evidence supports it, REFUTED if any piece contradicts it, and UNDECIDED otherwise. Keep that rule in every version you build.

## License

Use these prompts for anything, including selling what you build with them. Please don't resell the pack itself.
