# Build FogSift in your browser

Paste this into Claude at claude.ai. It builds FogSift as an interactive page you can keep, reuse, and share.

---

```
Build me an interactive web app called FogSift as an artifact. It turns a foggy idea into a fact-checked YouTube script. It should call Claude from inside the page to do the work.

The user types one idea and presses "Sift it." The app runs four stages in order and shows each one in its own tab along a progress rail at the top.

STAGE 1, THINK
Three roles discuss the idea:
- Coordinator: unpacks what the idea actually depends on
- Critic: attacks the weakest assumption
- Domain expert: adds concrete facts
Then extract 3 to 5 specific, falsifiable claims the idea depends on. Show each role's two sentences, then the numbered list of claims.

STAGE 2, PROVE
For each claim, build 1 to 3 evidence leaves. Grade each leaf:
- LIVE: a real source supports it
- DEAD: a real source contradicts it
- SAYS OTHERWISE: a source says something different
Each leaf names the most likely real source. Never invent statistics, quotes, or URLs.
The verdict is computed by code, not chosen by the AI: SUPPORTED if every leaf is LIVE, REFUTED if any leaf is DEAD, otherwise UNDECIDED.
Show each claim as a card with a colored verdict badge and its graded leaves. Add a note that sources are leads to check before publishing.

STAGE 3, PUBLISH
Write a script of about 4 minutes read aloud (550 to 650 words) using only the tested claims.
- State only SUPPORTED claims as true. Present UNDECIDED as uncertain and REFUTED as busted.
- Sections: HOOK, WHAT HELD UP, WHAT'S SHAKY, WHAT FAILED, THE REAL ANSWER, CTA. Drop any empty section. If nothing was supported or refuted, say so once.
- Each uncertain claim gets one or two sentences that could double as an on-screen checklist item.
- Tone: [honest, hopeful, plain-spoken]. No em dashes.
Also produce a title under 60 characters, thumbnail text of 2 to 4 words, and a 2 sentence description.
Show a 16:9 thumbnail mockup with the thumbnail text, the title, the script, and a Copy Script button.

SENTENCE CHECK (runs right after the script)
Go through the script sentence by sentence. Flag any factual sentence that asserts something no tested claim covers, or states an uncertain or busted claim as true. Show each flagged sentence with the problem and a fix. If none, show a CLEAN badge.

STAGE 4, REMEMBER
Save every tested claim with its verdict to a library tab that persists in this browser. Show newest first, with a Clear button.

DESIGN
Clean and calm, like fog lifting. Works on a phone. Light and dark mode. Open on a finished example run so the page never looks empty, clearly labeled as an example. If Claude can't be reached from the page, show the example run instead of an error.
```

---

**Tips**
- Change `[honest, hopeful, plain-spoken]` to your own tone before pasting.
- If something looks off, say "the Prove tab is cramped on my phone" or "make the badges bigger." Claude will fix it.
- See `examples/fogsift-web.html` for the version I built with this prompt.
