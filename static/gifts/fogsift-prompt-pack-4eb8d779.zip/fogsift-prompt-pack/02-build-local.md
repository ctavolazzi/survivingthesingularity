# Build FogSift on your own computer

Private, offline, no API bill. Paste this into Claude Code (or Claude at claude.ai if you'd rather copy the files yourself). You'll need [llama.cpp](https://github.com/ggml-org/llama.cpp) and an instruct model in `.gguf` format.

---

```
Build me a command-line tool called FogSift in Python 3.9+ using only the standard library. It turns a foggy idea into a fact-checked YouTube script using a local AI model.

ENGINE
- Default backend: llama.cpp's llama-server at http://localhost:8080, using its OpenAI-compatible /v1/chat/completions endpoint with response_format json_object and temperature 0.2. List models from /v1/models.
- Also support Ollama (http://localhost:11434, /api/generate with format json) through a `fogsift use llamacpp|ollama [--url]` command.
- Ask for JSON every time. If the reply isn't valid JSON, try to extract it, then retry once.
- `fogsift bench [targets]` times each model on a real Think task and saves the fastest one that returns at least 3 claims. For llama.cpp, targets are server URLs (one model per server). For Ollama, they're model names.
- Settings and library live in ~/.fogsift/.

PROMPTS
Keep each stage's prompt in its own text file in a prompts/ folder (think, prove, publish, check) with {{placeholders}}, so I can edit them without touching code.

`fogsift sift "idea"` RUNS FOUR STAGES:
1. Think: three roles (coordinator unpacks, critic attacks the weakest assumption, expert adds facts) then 3 to 5 falsifiable claims.
2. Prove: 1 to 3 evidence leaves per claim, graded LIVE, DEAD, or SAYS_OTHERWISE, each naming a likely real source. Never invent statistics or URLs. Pass in any similar claims already in the library. The verdict is computed in code, never by the model: SUPPORTED if all leaves LIVE, REFUTED if any DEAD, else UNDECIDED.
3. Publish: a 550 to 650 word script using only tested claims. SUPPORTED stated as true, UNDECIDED as uncertain, REFUTED as busted. Sections HOOK, WHAT HELD UP, WHAT'S SHAKY, WHAT FAILED, THE REAL ANSWER, CTA, dropping empty ones. Also a title, 2 to 4 word thumbnail text, and a 2 sentence description. Then a sentence check that flags any factual sentence not backed by a tested claim, with a fix for each.
4. Remember: save every claim, verdict, and its evidence to a SQLite library. `fogsift library [word]` lists or searches it.

OUTPUT
Each run gets a timestamped folder with:
- script.md: title, thumbnail text, script, description, a "Fix before recording" list, and the full claim graph
- receipts.html: a clean sources page listing every claim, verdict, and evidence leaf, for linking in video descriptions
- run.json: everything

Print short progress lines for each stage. Write a README with setup steps, including how to start llama-server. Then test the whole pipeline against a small fake llama-server so I know it works before I load a real model.
```

---

**Tips**
- A 7B model works. A 14B model gives noticeably better evidence.
- Running `llama-server -m your-model.gguf --port 8080` in one terminal and FogSift in another is the whole setup.
- See `examples/local-kit/` for the version I built with this prompt.
