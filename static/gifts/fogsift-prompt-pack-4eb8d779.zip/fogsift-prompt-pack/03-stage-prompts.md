# The stage prompts

These are the engine inside FogSift. You can run them by hand in any AI chat, one after another, with no app at all. Paste each prompt, fill in the brackets with the previous stage's output, and keep going.

---

## 1. Think

```
You run the Nova Process. Three roles discuss one idea:
- coordinator: unpacks what the idea actually depends on
- critic: attacks the weakest assumption
- expert: adds concrete domain facts

Then extract 3 to 5 specific, falsifiable claims the idea depends on. Each claim must be testable on its own.

Idea: [your idea]

Reply with JSON only:
{"roles":{"coordinator":"2 sentences","critic":"2 sentences","expert":"2 sentences"},"claims":["claim","claim","claim"]}
Plain language. No em dashes.
```

## 2. Prove

```
You are a strict fact-checker. For each claim, build 1 to 3 evidence leaves.
Grade each leaf:
- LIVE: a real source supports it
- DEAD: a real source contradicts it, or it plainly fails
- SAYS_OTHERWISE: a source says something different from the claim

For each leaf name the most likely real source. Never invent statistics, quotes, or URLs. When unsure, grade SAYS_OTHERWISE, not LIVE.

Claims to test: [claims from step 1]

Reply with JSON only:
{"claims":[{"claim":"","leaves":[{"grade":"LIVE|DEAD|SAYS_OTHERWISE","point":"","source":""}]}]}
No em dashes.
```

Then apply the verdict yourself, don't let the AI pick it:
- Every leaf LIVE → **SUPPORTED**
- Any leaf DEAD → **REFUTED**
- Anything else → **UNDECIDED**

## 3. Publish

```
Write a YouTube script from these tested claims. About 4 minutes read aloud (550 to 650 words).

Rules:
- State only SUPPORTED claims as true. Present UNDECIDED as uncertain and REFUTED as busted.
- Do not add any factual statement that is not one of the tested claims.
- Sections: HOOK, WHAT HELD UP, WHAT'S SHAKY, WHAT FAILED, THE REAL ANSWER, CTA. Omit any empty section. If nothing is SUPPORTED or REFUTED, say so once inside WHAT'S SHAKY.
- Each uncertain claim gets one or two sentences, phrased so it can double as an on-screen checklist item.
- Tone: [honest, hopeful, plain-spoken]. No em dashes.

Original idea: [your idea]
Tested claims with verdicts: [claims and verdicts from step 2]

Reply with JSON only:
{"title":"under 60 characters","thumb":"thumbnail text, 2 to 4 words","script":"the full script","description":"2 sentences"}
```

## 4. Sentence check

```
Read this script sentence by sentence. Skip greetings, questions, calls to action, and clearly labeled opinion.

Flag any factual sentence that:
- asserts something not covered by a tested claim, or
- states an UNDECIDED or REFUTED claim as true.

Tested claims: [claims and verdicts]
Script: [script from step 3]

Reply with JSON only:
{"flags":[{"sentence":"exact sentence","problem":"short reason","fix":"cut it, or the source that would ground it"}]}
Return an empty list if the script is clean. No em dashes.
```

## 5. Remember

Keep a running list of every claim you've tested and its verdict. Before your next run, paste the related ones into the Prove prompt: "Claims already tested: [list]." Over time this becomes your own verified knowledge base.
