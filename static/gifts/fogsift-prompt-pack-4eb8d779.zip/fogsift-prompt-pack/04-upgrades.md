# Upgrade prompts

Paste any of these into the same Claude conversation (or Claude Code session) where you built FogSift.

## Real thumbnails
```
Add a thumbnail step that turns the thumbnail text into a 1280x720 image with huge bold text and a verdict stamp: SUPPORTED, BUSTED, or UNCERTAIN, based on the overall result.
```

## Shorts
```
Add a Shorts option that writes one 45 second script per claim. Each opens with the claim as a question and ends with the verdict.
```

## Live research
```
Add a research mode to the Prove stage. Use web search to find a real URL for every evidence leaf and quote no more than one short line from each. Downgrade any leaf whose source can't be found to SAYS_OTHERWISE. The code still decides the verdict.
```

## Sift a folder or document
```
Add a scan mode. I give it a folder of notes or a long document, and it pulls out the strongest checkable claims and lists them as a queue. Show me the queue before running anything.
```

## Quiz mode
```
Add a quiz mode that turns a finished claim graph into a 20 question test, mixing multiple choice and true/false, with an answer key that cites the evidence. Use it to prove you learned the topic.
```

## Your voice
```
Rewrite the Publish stage prompt so scripts sound like me. Here are three scripts or posts I've written: [paste]. Keep every rule about only stating tested claims.
```

## Follow-up episodes
```
Add a Rerun option. I paste viewer comments with real numbers or sources, and it adds them as new evidence leaves to the same claims, recomputes the verdicts, and writes a short follow-up script about what changed.
```

## Receipts page
```
Add a Receipts export: a clean, shareable page listing every claim, its verdict, and its evidence, made to link in a video description.
```
