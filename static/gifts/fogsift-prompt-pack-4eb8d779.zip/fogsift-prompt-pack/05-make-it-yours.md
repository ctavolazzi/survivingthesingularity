# Make it yours

FogSift works on any topic. Add one of these lines to the end of either build prompt to tune it to your niche.

**Cooking and nutrition**
```
Tune FogSift for food and nutrition claims. Prefer evidence from peer-reviewed nutrition research, government dietary guidelines, and food science sources. Flag any health claim that needs a doctor's input.
```

**Personal finance**
```
Tune FogSift for money claims. Prefer evidence from government statistics, regulator publications, and historical market data. Always flag claims that depend on someone's personal situation, and add a line that this isn't financial advice.
```

**Fitness**
```
Tune FogSift for fitness and training claims. Prefer sports science research and position statements from professional bodies. Mark claims that only apply to certain ages or experience levels.
```

**Tech and AI news**
```
Tune FogSift for tech news. Prefer primary sources: company announcements, papers, changelogs, and official docs over coverage of them. Mark any claim that may be out of date within a month.
```

**Home and DIY**
```
Tune FogSift for home, garden, and DIY claims. Prefer manufacturer specs, university extension guides, and building codes. Flag safety-related claims clearly.
```

**Local news**
```
Tune FogSift for local news in [your city]. Prefer city and county records, meeting minutes, and local reporting. Note when a claim needs a direct quote from an official.
```

**Your own idea**
```
Tune FogSift for [your topic]. The best sources for this topic are [list them]. The claims people get wrong most often are [describe].
```
