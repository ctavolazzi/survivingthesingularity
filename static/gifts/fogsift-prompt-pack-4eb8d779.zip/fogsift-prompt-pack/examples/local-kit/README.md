# FogSift

Turn a foggy idea into a verified, publishable video script. On your own computer. No API bill.

```
fogsift sift "Home robot gardens pay for themselves in two years"
```

FogSift runs your idea through five stages:

| Stage | What happens | Built from |
|---|---|---|
| 0 Engine | Benchmarks your local models and picks the fastest one that does the job | bytebrain |
| 1 Think | Three roles (coordinator, critic, expert) unpack the idea into testable claims | NovaSystem |
| 2 Prove | Each claim gets an evidence graph. The graph, not the AI, decides the verdict | claimground |
| 3 Publish | Writes a ~4 minute script from what survived, then flags any sentence that isn't backed | claimground, claude-youtube-editor |
| 4 Remember | Every tested claim goes into a local library you can search and reuse | SimpleAgentOS journal |

Each run saves a folder with `script.md` (ready to record, with thumbnail text and a fix list), `receipts.html` (a sources page for your video description), and `run.json` (everything).

## Setup (about 10 minutes)

1. Install Python 3.9 or newer.
2. Install [llama.cpp](https://github.com/ggml-org/llama.cpp) (on a Mac: `brew install llama.cpp`).
3. Download an instruct model in `.gguf` format (a 7B to 14B model at Q4 fits most laptops) and start the server:
   ```
   llama-server -m path/to/model.gguf --port 8080
   ```
4. In a second terminal, from this folder:
   ```
   python3 fogsift.py bench
   python3 fogsift.py sift "your idea here"
   ```

No packages to install. Standard library only.

**Comparing models:** llama-server runs one model at a time. Start a few on different ports, then `python3 fogsift.py bench http://localhost:8080 http://localhost:8081` and FogSift keeps the fastest one that does the job.

**Prefer Ollama?** Run `python3 fogsift.py use ollama`, then `bench` picks among your pulled models. Switch back with `use llamacpp`.

## Commands

| Command | Does |
|---|---|
| `fogsift.py sift "idea"` | Full run. Use `-` to read a long idea from a file: `fogsift.py sift - < notes.txt` |
| `fogsift.py bench [urls or models]` | Test your local models and save the best one |
| `fogsift.py use llamacpp\|ollama [--url]` | Switch engine (llama.cpp is the default) |
| `fogsift.py library [word]` | List or search everything you've tested |

Your library and settings live in `~/.fogsift/`.

## Be honest about the limits

Local models can't browse the web. The Prove stage names the sources a claim needs and grades them from what the model knows. Treat every source as a lead: open it and confirm before you publish. To add live research, use the Claude Code prompts in `PROMPTS.md`.

## Make it yours

Open this folder in Claude Code and paste any prompt from `PROMPTS.md`. The prompts in `prompts/` control every stage; edit them to change tone, length, or format.

## License

GPL-3.0, because FogSift builds on NovaSystem. You can use, change, and resell it, as long as you share your source under the same license.
