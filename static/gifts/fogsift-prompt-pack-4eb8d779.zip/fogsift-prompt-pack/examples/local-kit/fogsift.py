#!/usr/bin/env python3
"""FogSift: turn a foggy idea into a verified, publishable video script.

Stages: engine (pick a local model), think (Nova roles), prove (claim graph),
publish (script + sentence check), remember (SQLite library).
Runs on your own computer. Default engine: llama.cpp (llama-server). Ollama also supported.
Python 3.9+, standard library only.
"""
import argparse, json, os, re, sqlite3, sys, time, urllib.request
from datetime import datetime
from pathlib import Path

HOME = Path(os.environ.get("FOGSIFT_HOME", Path.home() / ".fogsift"))
DB = HOME / "library.db"
CFG = HOME / "config.json"
PROMPTS = Path(__file__).parent / "prompts"
DEFAULT_URL = {"llamacpp": "http://localhost:8080", "ollama": "http://localhost:11434"}


# ---------- engine ----------
def backend():
    return os.environ.get("FOGSIFT_BACKEND") or cfg().get("backend") or "llamacpp"

def base_url():
    b = backend()
    return (os.environ.get("FOGSIFT_URL") or cfg().get("url") or
            (os.environ.get("OLLAMA_HOST") if b == "ollama" else None) or DEFAULT_URL[b])

def http(path, body=None, timeout=600, url=None):
    req = urllib.request.Request((url or base_url()) + path, data=json.dumps(body).encode() if body else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())

def models(url=None):
    try:
        if backend() == "ollama":
            return [m["name"] for m in http("/api/tags", url=url)["models"]]
        return [m["id"] for m in http("/v1/models", url=url)["data"]]
    except Exception as e:
        hint = ("Start it with `llama-server -m path/to/model.gguf --port 8080`."
                if backend() == "llamacpp" else "Start it with `ollama serve`.")
        sys.exit(f"Can't reach {backend()} at {url or base_url()}. {hint} ({e})")

def cfg():
    try: return json.loads(CFG.read_text())
    except Exception: return {}

def save_cfg(c):
    HOME.mkdir(parents=True, exist_ok=True); CFG.write_text(json.dumps(c, indent=2))

def current_model(override=None):
    m = override or cfg().get("model")
    if m: return m
    ms = models()
    if not ms: sys.exit("No model loaded. Start llama-server with a .gguf model.")
    return ms[0]

def generate(model, prompt, url=None):
    if backend() == "ollama":
        r = http("/api/generate", {"model": model, "prompt": prompt, "stream": False,
                                   "format": "json", "options": {"temperature": 0.2}}, url=url)
        return r.get("response", "")
    r = http("/v1/chat/completions", {"model": model, "temperature": 0.2,
                                      "messages": [{"role": "user", "content": prompt}],
                                      "response_format": {"type": "json_object"}}, url=url)
    return r["choices"][0]["message"]["content"]

def ask_json(model, prompt, url=None):
    """Ask the local model for JSON, retry once on bad output."""
    for attempt in range(2):
        txt = generate(model, prompt, url)
        try:
            return json.loads(txt)
        except json.JSONDecodeError:
            m = re.search(r"[\[{].*[\]}]", txt, re.S)
            if m:
                try: return json.loads(m.group(0))
                except json.JSONDecodeError: pass
        prompt += "\n\nYour last reply was not valid JSON. Reply with JSON only."
    raise RuntimeError("Model did not return valid JSON. Try a larger model.")

def prompt(name, **kw):
    text = (PROMPTS / f"{name}.txt").read_text()
    for k, v in kw.items():
        text = text.replace("{{" + k + "}}", v if isinstance(v, str) else json.dumps(v, indent=1))
    return text

def bench(args):
    """Stage 0: engine. Time each local model on a real FogSift task.
    llama.cpp: pass several server URLs (one model per llama-server) to compare them.
    Ollama: compares installed models, or the names you pass."""
    test = prompt("think", idea="Drinking coffee every day makes people live longer.")
    if backend() == "llamacpp":
        targets = [(models(u)[0], u) for u in (args.targets or [base_url()])]
    else:
        targets = [(m, base_url()) for m in (args.targets or models())]
    rows = []
    for m, u in targets:
        print(f"  testing {m} at {u} ...", end="", flush=True)
        t = time.time()
        try:
            out = ask_json(m, test, u)
            ok = isinstance(out.get("claims"), list) and len(out["claims"]) >= 3
            rows.append((m, u, time.time() - t, ok)); print(f" {time.time()-t:.1f}s {'ok' if ok else 'weak output'}")
        except Exception as e:
            rows.append((m, u, 9e9, False)); print(f" failed ({e})")
    good = sorted([r for r in rows if r[3]], key=lambda r: r[2])
    if not good: sys.exit("No model produced usable output. Try a larger .gguf model (7B or up).")
    c = cfg(); c.update(model=good[0][0], url=good[0][1], backend=backend()); save_cfg(c)
    print(f"\nEngine set to {good[0][0]} on {backend()} at {good[0][1]}.")

def use(args):
    c = cfg(); c["backend"] = args.backend; c.pop("model", None)
    if args.url: c["url"] = args.url
    else: c.pop("url", None)
    save_cfg(c); print(f"Engine backend set to {args.backend} at {base_url()}.")


# ---------- library ----------
def db():
    HOME.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS claims(
        id INTEGER PRIMARY KEY, at TEXT, idea TEXT, claim TEXT, verdict TEXT, leaves TEXT)""")
    return con

def remember(idea, proved):
    con = db()
    for p in proved:
        con.execute("INSERT INTO claims(at,idea,claim,verdict,leaves) VALUES(?,?,?,?,?)",
                    (datetime.now().isoformat(timespec="seconds"), idea, p["claim"], p["verdict"],
                     json.dumps(p.get("leaves", []))))
    con.commit()

def known(idea):
    """Previously tested claims that share words with this idea."""
    words = {w for w in re.findall(r"[a-z]{5,}", idea.lower())}
    if not words: return []
    con = db(); rows = con.execute("SELECT claim, verdict FROM claims ORDER BY id DESC LIMIT 500").fetchall()
    return [{"claim": c, "verdict": v} for c, v in rows if words & set(re.findall(r"[a-z]{5,}", c.lower()))][:8]

def library(args):
    con = db()
    q = "SELECT at, verdict, claim FROM claims"
    rows = con.execute(q + (" WHERE claim LIKE ? ORDER BY id DESC" if args.search else " ORDER BY id DESC LIMIT 50"),
                       (f"%{args.search}%",) if args.search else ()).fetchall()
    if not rows: print("Library is empty. Run `fogsift sift \"your idea\"` first."); return
    for at, v, c in rows: print(f"{at[:10]}  {v:<10} {c}")


# ---------- pipeline ----------
def verdict_of(leaves):
    g = [l.get("grade") for l in leaves]
    if g and all(x == "LIVE" for x in g): return "SUPPORTED"
    if "DEAD" in g: return "REFUTED"
    return "UNDECIDED"

def sift(args):
    idea = args.idea if args.idea != "-" else sys.stdin.read().strip()
    model = current_model(args.model)
    out = Path(args.out or "runs") / (datetime.now().strftime("%Y%m%d-%H%M") + "-" +
                                      re.sub(r"[^a-z0-9]+", "-", idea.lower())[:40].strip("-"))
    out.mkdir(parents=True, exist_ok=True)
    print(f"FogSift  ·  engine: {model} on {backend()}\n")

    print("1 Think: three roles unpack the idea")
    think = ask_json(model, prompt("think", idea=idea))
    for k, v in think.get("roles", {}).items(): print(f"   {k}: {v}")
    claims = think["claims"]

    print("\n2 Prove: testing each claim")
    prior = known(idea)
    proved = ask_json(model, prompt("prove", claims=claims, prior=prior or "none"))
    proved = proved.get("claims", proved) if isinstance(proved, dict) else proved
    for p in proved:
        p["verdict"] = verdict_of(p.get("leaves", []))  # the graph decides, not the model
        print(f"   [{p['verdict']}] {p['claim']}")

    print("\n3 Publish: writing the script")
    pub = ask_json(model, prompt("publish", idea=idea, proved=proved))

    print("   checking every sentence")
    check = ask_json(model, prompt("check", proved=[{"claim": p["claim"], "verdict": p["verdict"]} for p in proved],
                                   script=pub.get("script", "")))
    flags = check.get("flags", [])
    print(f"   {'CLEAN' if not flags else str(len(flags)) + ' ungrounded sentence(s)'}")

    remember(idea, proved)
    print("\n4 Remember: claims saved to your library")

    (out / "run.json").write_text(json.dumps({"idea": idea, "model": model, "think": think,
                                              "prove": proved, "publish": pub, "check": check}, indent=2))
    (out / "script.md").write_text(render_md(idea, think, proved, pub, flags))
    (out / "receipts.html").write_text(render_receipts(idea, proved, pub))
    print(f"\nDone. Open {out}/script.md to record, and {out}/receipts.html for your sources page.")

def render_md(idea, think, proved, pub, flags):
    s = [f"# {pub.get('title','')}", "", f"**Thumbnail text:** {pub.get('thumb','')}", "",
         pub.get("script", ""), "", "## Description", pub.get("description", ""), ""]
    if flags:
        s += ["## Fix before recording", ""]
        s += [f"- **{f.get('sentence')}**  \n  {f.get('problem')} Fix: {f.get('fix')}" for f in flags]
    s += ["", "## Claim graph", ""]
    for p in proved:
        s.append(f"- **[{p['verdict']}]** {p['claim']}")
        s += [f"  - {l.get('grade')}: {l.get('point')} ({l.get('source')})" for l in p.get("leaves", [])]
    return "\n".join(s) + "\n"

def render_receipts(idea, proved, pub):
    esc = lambda x: str(x).replace("&", "&amp;").replace("<", "&lt;")
    items = "".join(f"<section><h2>{esc(p['verdict'])}: {esc(p['claim'])}</h2><ul>" +
                    "".join(f"<li><b>{esc(l.get('grade'))}</b> {esc(l.get('point'))} <i>{esc(l.get('source'))}</i></li>"
                            for l in p.get("leaves", [])) + "</ul></section>" for p in proved)
    return f"""<!doctype html><meta charset=utf-8><title>Receipts: {esc(pub.get('title',''))}</title>
<style>body{{font:16px/1.5 system-ui;max-width:720px;margin:40px auto;padding:0 16px}}h2{{font-size:17px}}</style>
<h1>Receipts</h1><p>Every claim in "{esc(pub.get('title',''))}" and the evidence behind it. Sources marked for verification were checked before publishing.</p>
<p><b>Original idea:</b> {esc(idea)}</p>{items}<p><small>Made with FogSift</small></p>"""


def main():
    ap = argparse.ArgumentParser(prog="fogsift", description="Turn a foggy idea into a verified video script.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("sift", help="run an idea through all stages"); a.add_argument("idea", help='the idea, or "-" to read stdin')
    a.add_argument("--model"); a.add_argument("--out"); a.set_defaults(fn=sift)
    b = sub.add_parser("bench", help="pick the best local model for this computer")
    b.add_argument("targets", nargs="*", help="llama.cpp: server URLs to compare; ollama: model names"); b.set_defaults(fn=bench)
    u = sub.add_parser("use", help="switch engine: llamacpp (default) or ollama")
    u.add_argument("backend", choices=["llamacpp", "ollama"]); u.add_argument("--url"); u.set_defaults(fn=use)
    c = sub.add_parser("library", help="list or search tested claims"); c.add_argument("search", nargs="?"); c.set_defaults(fn=library)
    args = ap.parse_args(); args.fn(args)

if __name__ == "__main__":
    main()
